package com.ritwik.payloaddetector

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ritwik.payloaddetector.databinding.ActivitySingleAppBinding
import com.ritwik.payloaddetector.singleApp.ViewHolder as ViewHolder1

class singleApp : AppCompatActivity() {
    private lateinit var binding: ActivitySingleAppBinding
    val permissionList = arrayListOf<String>()
    val servicesList = arrayListOf<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySingleAppBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (intent.extras != null) {
            val packageName = intent.extras!!["PACKAGE_NAME"].toString()
            Log.d(TAG, "onCreate: Package Name = $packageName")
            // getting application Info
            val appInfo = packageManager.getApplicationInfo(packageName, 0)

            val categoryTitle =  ApplicationInfo.getCategoryTitle(this, appInfo.category)
            Log.d(TAG, "onCreate: app Category = $categoryTitle")
             if(categoryTitle!="null") {
                binding.asaAppCategory.setText("App Category - $categoryTitle")
            }
            else
            {
                binding.asaAppCategory.setText("App Category - Undefined")
            }
            if(binding.asaAppCategory.text == "App Category - null")
            {
                binding.asaAppCategory.setTextColor(Color.RED)
            }

            getAppPermissions(appInfo)
            // getting installation source info
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
               val installationSource =  packageManager.getInstallSourceInfo(packageName)
                Log.d(TAG, "onCreate: installation source = $installationSource")
                binding.asaAppSource.text = "Source = $installationSource"
            }
            else
            {
                val installerName = packageManager.getInstallerPackageName(packageName)
                Log.d(TAG, "onCreate: lower android version")
                Log.d(TAG, "onCreate: installer package Name = $installerName")
                binding.asaAppSource.text = "Source = $installerName"
            }
            if(binding.asaAppSource.text == "Source = null")
            {
                Log.d(TAG, "onCreate: Unknown source")
                binding.asaAppSource.setTextColor(Color.RED)
                binding.asaAppStatus.setTextColor(Color.RED)
                binding.asaAppStatus.text = "The App might not be safe"
            }
            val appName = appInfo.loadLabel(packageManager)
            Log.d(TAG, "onCreate: app name = $appName")
            binding.asaAppName.setText(appName)
            // setting app logo
            val appLogo = appInfo.loadIcon(packageManager)
            binding.asaAppIcon.setImageDrawable(appLogo)


        } else {
            Log.d(TAG, "onCreate: Intent data is null")
        }
        binding.asaBack.setOnClickListener {
            finish()
        }
        val adapter = object : RecyclerView.Adapter<ViewHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
                val view = LayoutInflater.from(this@singleApp)
                    .inflate(R.layout.single_permission, parent, false)
                return ViewHolder(view)
            }

            override fun onBindViewHolder(holder: ViewHolder, position: Int) {
                holder.setName(permissionList[position])
            }

            override fun getItemCount(): Int {
                return permissionList.size
            }

        }
        binding.asaPermissionRecycler.layoutManager = LinearLayoutManager(this)
        binding.asaPermissionRecycler.adapter = adapter
        val serviceAdapter = object : RecyclerView.Adapter<ServiceViewHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServiceViewHolder {
                val view = layoutInflater.inflate(R.layout.single_permission, parent, false)
                return ServiceViewHolder(view)
            }

            override fun onBindViewHolder(holder: ServiceViewHolder, position: Int) {
                holder.setServiceName(servicesList[position])
            }

            override fun getItemCount(): Int {
                return servicesList.size
            }

        }
        binding.asaServicesRecycler.layoutManager = LinearLayoutManager(this)
        binding.asaServicesRecycler.adapter = serviceAdapter
    }

    private fun getAppPermissions(appInfo: ApplicationInfo) {
        val packageInfo =
            packageManager.getPackageInfo(appInfo.packageName, PackageManager.GET_PERMISSIONS)
        // setting version code
        binding.asaVersionCode.setText("Version Name = ${packageInfo.versionName}")
        val permissions = packageInfo.requestedPermissions

        if (permissions != null) {
            for (permission in permissions) {
                //Log.d(TAG, "onCreate: ${permission}")
                permissionList.add(permission)
                binding.asaPermissionCount.setText("No of permissions required = ${permissionList.size}")
            }
        }
        val services = packageInfo.services
        if (services != null) {
            for (service in services) {
                Log.d(TAG, "getAppPermissions: service name = ${service.name}")
                servicesList.add(service.name)
            }
        }
        else
        {
            Log.d(TAG, "getAppPermissions: No services found")
        }
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val permissionName = itemView.findViewById<TextView>(R.id.sp_Name)
        fun setName(name: String) {

            permissionName.setText(name)
        }
    }

    inner class ServiceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val serviceName = itemView.findViewById<TextView>(R.id.sp_Name)
        fun setServiceName(name: String) {
            Log.d(TAG, "setServiceName: ${name}")
            serviceName.setTextColor(Color.RED)
            serviceName.setText(name)
        }

    }

    companion object {
        private const val TAG = "singleApp"
    }


}