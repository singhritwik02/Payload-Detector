package com.ritwik.payloaddetector

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.*
import com.ritwik.payloaddetector.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var binding:ActivityMainBinding
    private var appList = arrayListOf<String>()
    private var appIconList = arrayListOf<Drawable>()
    private var packageList = arrayListOf<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val recycler=binding.amAllAppsRecycler
        recycler.layoutManager = LinearLayoutManager(this)
        val adapter = Adapter()
        recycler.adapter = adapter
        adapter.notifyDataSetChanged()
        appList.clear()
        appList.addAll(getAppList())
        adapter.notifyDataSetChanged()

    }
    companion object
    {
        private const val TAG = "MainActivity"
    }
    inner class Adapter: RecyclerView.Adapter<ViewHolder>()
    {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = layoutInflater.inflate(R.layout.single_app,parent,false)
            return ViewHolder(view)
        }


        override fun getItemCount(): Int {
            return  appList.size
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            Log.d(TAG, "onBindViewHolder: ")
            holder.setAppName(appList[position])
            holder.setIcon(appIconList[position])
            holder.itemView.setOnClickListener {
                val intent = Intent(this@MainActivity,singleApp::class.java)
                intent.putExtra("PACKAGE_NAME",packageList[position])
                startActivity(intent)

            }
        }

    }
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
    {
        val appName = itemView.findViewById<TextView>(R.id.sa_AppName)
        val appIcon = itemView.findViewById<ImageView>(R.id.sa_Icon)
        fun setAppName(name:String)
        {
            appName.setText(name)
        }
        fun setIcon(image:Drawable)
        {
            appIcon.setImageDrawable(image)
        }
    }
    private fun getAppList():ArrayList<String>
    {
        val mainIntent = Intent(Intent.ACTION_MAIN, null)
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER)
        val pkgAppsList: List<ResolveInfo> =
            getPackageManager().queryIntentActivities(mainIntent, 0)
        Log.d(TAG, "getAppList: size = ${pkgAppsList.size}")
        val arrayList = arrayListOf<String>()
        val pckList = packageManager.getInstalledPackages(0)
        var appInfo:ApplicationInfo? = null
        var appname = ""
        var iconDrawable:Drawable? = null
        for(pck in pckList)
        {
        packageList.add(pck.packageName)
            appInfo = packageManager.getApplicationInfo(pck.packageName,0)
            arrayList.add(appInfo!!.loadLabel(packageManager).toString())
            appIconList.add(appInfo!!.loadIcon(packageManager))


        }
        val bundle = Bundle()

        return arrayList
    }
}